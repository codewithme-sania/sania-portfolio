# Shaik Sania — Portfolio Website

## Files
- `index.html` — complete responsive portfolio (HTML, CSS, and JavaScript included)
- `assets/sania-profile.jpg` — your profile photo

## Run locally
Open `index.html` in your browser.

## Customize
Update the project descriptions/links as needed. The portfolio links currently point to public repositories found on `github.com/codewithme-sania`. Add your graphic design portfolio/blog/video links when ready.

## Publish
You can publish this folder with GitHub Pages. Keep the `assets` folder next to `index.html` so your photo loads correctly.
